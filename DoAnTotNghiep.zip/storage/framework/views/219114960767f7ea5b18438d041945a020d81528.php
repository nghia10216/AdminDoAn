

<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Thông tin ngành
                    <small>danh sách</small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <?php if(session('thongbao')): ?>
            <div class="alert alert-success">
                <?php echo e(session('thongbao')); ?>

            </div>
            <?php endif; ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr style="background: #83b7e3" align="center">
                        <th>ID</th>
                        <th>Trình độ đào tạo</th>
                        <th>Hình thức đào tạo</th>
                        <th>Thời gian đào tạo</th>
                        <th>Thời gian tuyển sinh nộp hồ sơ</th>
                        <th>Thời gian xét tuyển và nhập học</th>
                        <th>hình thức tuyển sinh</th>
                        <th>Tôt hợp môn xét tuyển</th>
                        <th>Điểm chuẩn các năm</th>
                        <th>Chỉ tiêu</th>
                        <th>Học phí</th>
                        <th>Ảnh giới thiệu</th>
                        <th>Ngành</th>

                        <th>Delete</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $thongtinnganhdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thongtinnganh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd gradeX" align="center">
                        <td><?php echo e($thongtinnganh->id); ?></td>
                        <td><?php echo e($thongtinnganh->TrinhDoDaoTao); ?></td>
                        <td><?php echo e($thongtinnganh->HinhThucDaoTao); ?></td>
                        <td><?php echo e($thongtinnganh->ThoiGianDaoTao); ?></td>
                        <td><?php echo e($thongtinnganh->ThoiGianTuyenSinhNopHoSo); ?></td>
                        <td><?php echo e($thongtinnganh->ThoiGianXetTuyenVaNhapHoc); ?></td>
                        <td><?php echo e($thongtinnganh->HinhThucTuyenSinh); ?></td>
                        <td><?php echo e($thongtinnganh->ToHopMonXetTuyen); ?></td>
                        <td><?php echo e($thongtinnganh->DiemChuanCacNam); ?></td>
                        <td><?php echo e($thongtinnganh->ChiTieu); ?></td>
                        <td><?php echo e($thongtinnganh->HocPhi); ?></td>
                        <td><img width="100px" src="upload/anhgioithieu/<?php echo e($thongtinnganh->AnhGioiThieu); ?>" alt=""></td>
                        <td><?php echo e($thongtinnganh->nganh->TenNganh); ?></td>
                        

                        <td class="center"><a class="btn btn-danger" href="admin/thongtinnganh/xoa/<?php echo e($thongtinnganh->id); ?>">
                                <i class="fa fa-trash-o  fa-fw"></i> Xóa</a></td>
                        <td class="center"><a class="btn btn-success" href="admin/thongtinnganh/sua/<?php echo e($thongtinnganh->id); ?>">
                                <i class="fa fa-pencil fa-fw"></i> Sửa</a></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\DoAnTotNghiep\resources\views/admin/thongtinnganh/danhsach.blade.php ENDPATH**/ ?>