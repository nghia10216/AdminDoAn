

<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Khoa
                    <small>danh sách</small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <?php if(session('thongbao')): ?>
            <div class="alert alert-success">
                <?php echo e(session('thongbao')); ?>

            </div>
            <?php endif; ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr style="background: #83b7e3" align="center">
                        <th>ID</th>
                        <th>Tên khoa</th>
                        <th>LogoKhoa</th>
                        <th>SDT</th>
                        <th>Email</th>
                        
                        <th>Xóa</th>
                        <th>Sửa</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $khoadata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khoa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd gradeX" align="center">
                        <td><?php echo e($khoa->id); ?></td>
                        <td><?php echo e($khoa->TenKhoa); ?></td>
                        <td><img width="100px" src="upload/logoKhoa/<?php echo e($khoa->LogoKhoa); ?>" alt=""></td>
                        <td><?php echo e($khoa->SDT); ?></td>
                        <td><?php echo e($khoa->Email); ?></td>
                        
                        

                        
                        <td class="center"><a class="btn btn-danger" href="admin/khoa/xoa/<?php echo e($khoa->id); ?>">
                                <i class="fa fa-trash-o  fa-fw"></i> Xóa</a></td>
                        <td class="center"><a class="btn btn-success" href="admin/khoa/sua/<?php echo e($khoa->id); ?>">
                                <i class="fa fa-pencil fa-fw"></i> Sửa</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\DoAnTotNghiep\resources\views/admin/khoa/danhsach.blade.php ENDPATH**/ ?>