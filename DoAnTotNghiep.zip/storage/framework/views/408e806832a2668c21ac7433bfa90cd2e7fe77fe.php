

<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Ngành
                    <small>danh sách</small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <?php if(session('thongbao')): ?>
            <div class="alert alert-success">
                <?php echo e(session('thongbao')); ?>

            </div>
            <?php endif; ?>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr style="background: #83b7e3" align="center">
                        <th>ID</th>
                        <th>Mã ngành</th>
                        <th>Tên ngành</th>
                        <th>Bằng tốt nghiệp</th>
                        
                        <th>Khung chương trình đào tạo</th>
                        <th>Khoa</th>


                        <th>Xóa</th>
                        <th>Sửa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $nganhdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nganh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd gradeX" align="center">
                        <td><?php echo e($nganh->id); ?></td>
                        <td><?php echo e($nganh->MaNganh); ?></td>
                        <td><?php echo e($nganh->TenNganh); ?></td>
                        <td><?php echo e($nganh->BangTotNghiep); ?></td>
                        
                        <td><?php echo e($nganh->KhungChuongTrinhDaoTao); ?></td>

                        <td><?php echo e($nganh->khoa->TenKhoa); ?></td>
                        

                        <td class="center"><a class="btn btn-danger" href="admin/nganh/xoa/<?php echo e($nganh->id); ?>">
                                <i class="fa fa-trash-o  fa-fw"></i> Xóa</a></td>
                        <td class="center"><a class="btn btn-success" href="admin/nganh/sua/<?php echo e($nganh->id); ?>">
                                <i class="fa fa-pencil fa-fw"></i> Sửa</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\DoAnTotNghiep\resources\views/admin/nganh/danhsach.blade.php ENDPATH**/ ?>